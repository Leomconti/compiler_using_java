package com.example.compiler_testes;

public class Main {
    public static void main(String[] args){
        CodeEditorApplication.main(args);
    }
}
